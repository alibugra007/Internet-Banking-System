﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Internet_Bankacılığı_Proje
{
    class KartlarımClass
    {
        public DataTable KrediKartLimit(int musteriNo)
        {
            SqlConnection connection = null;
            try
            {

                string query = $"select [Kredi Kartı Numarası],[Kredi Kartı Limiti] from KrediKart where [Müşteri Numarası]={musteriNo}";

                return dbHelper.ExecuteQuery(query);

            }
            catch (Exception Ex)
            {

                throw new Exception(Ex.Message);
            }

        }

        public DataTable KrediKartBorç(int musteriNo)
        {
            SqlConnection connection = null;
            try
            {

                string query = $"select [Kredi Kartı Numarası],[Kredi Kartı Borç] from KrediKart where [Müşteri Numarası]={musteriNo}";

                return dbHelper.ExecuteQuery(query);

            }
            catch (Exception Ex)
            {

                throw new Exception(Ex.Message);
            }

        }

        public DataTable BankaKartG(int musteriNo)
        {
            SqlConnection connection = null;
            try
            {

                string query = $"SELECT [Banka Kartı Numarası],[Banka Kartı Bakiyesi],[Müşteri Numarası] FROM BankaKart where [Müşteri Numarası]={musteriNo}";

                return dbHelper.ExecuteQuery(query);

            }
            catch (Exception Ex)
            {

                throw new Exception(Ex.Message);
            }

        }



    }
}
