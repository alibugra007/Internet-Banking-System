﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Internet_Bankacılığı_Proje
{
    class ÖdemelerClass
    {
        float ödeme;
        string musterino;
        public float Ödeme { get => ödeme; set => ödeme = value; }
        public string Musterino { get => musterino; set => musterino = value; }

        public DataTable ÖdemelerKrediKartBorçG(int musteriNo)
        {
            SqlConnection connection = null;
            try
            {

                //Kayıt tcalma = new Kayıt();
                //string tc = tcalma.tbTC.Text.Trim();

                string query = $"select [Kredi Kartı Numarası],[Kredi Kartı Borç] from KrediKart where [Müşteri Numarası]={musteriNo}"; //where [T.C. Kimlik Numarası]={tc}

                return dbHelper.ExecuteQuery(query);

            }
            catch (Exception Ex)
            {

                throw new Exception(Ex.Message);
            }

        }

        public void ÖdemelerKrediKartıOdeme(float odenecekDeger,int krediKartıNum,int musterino)
        {
            SqlConnection connection = null;
            try
            {
                string conString = "Server=DESKTOP-FNI8T1F;Database=proje;Trusted_Connection=True;";
                connection = new SqlConnection(conString); // using System.Data.SqlClient; bunu en yukarıda import etmeliyiz yoksa çalışmaz.
                connection.Open();

                string query1 = $"Select [Kredi Kartı Borç] from kredikart WHERE [Kredi Kartı Numarası]={krediKartıNum} AND [Müşteri Numarası] = {musterino}";
                SqlCommand command = new SqlCommand(query1, connection); // komutumuzu sql de yazmak için yaptık. 

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                    //ÖdemelerClass ÖC = new ÖdemelerClass();
                    float Borç = float.Parse(dt.Rows[0][0].ToString());

                    float sondeger = Borç - odenecekDeger;

                    string query2 = $"UPDATE KrediKart SET [Kredi Kartı Borç] = {sondeger}  WHERE [Kredi Kartı Numarası]={krediKartıNum} ";
                    SqlCommand command2 = new SqlCommand(query2, connection); // komutumuzu sql de yazmak için yaptık. 
 
            }
            catch (Exception Ex)
            {

                throw new Exception(Ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        //public DataTable ÖdemelerBorçÖdeme(string query,string Musterino)
        //{
        //    SqlConnection connection = null;
        //    try
        //    {

        //        string conString = "Server=DESKTOP-FNI8T1F;Database=proje;Trusted_Connection=True;"; // bağlanma stringi connectionstring.com diye bir siteden alabiliriz.
        //        //Trusted_Connection=True demek windows authentication kullanıyoruz demek.

        //        connection = new SqlConnection(conString); // using System.Data.SqlClient; bunu en yukarıda import etmeliyiz yoksa çalışmaz.
        //        connection.Open(); // veri tabanıyla bağlantı yapıldı.

        //        if (connection.State == System.Data.ConnectionState.Open)
        //        {
        //            // query = $"select * from Course "; yukarıda parametre olarak aldığı için gerek kalmadı buna

        //            SqlCommand command = new SqlCommand(query, connection); // komutumuzu sql de yazmak için yaptık. 
        //            SqlDataAdapter adapter = new SqlDataAdapter(command); // bilgiyi ordan okudu ve aldı.

        //            DataTable dt = new DataTable(); // 2 boyutlu array gibi. Verileri kopyalamak için buraya.
        //            adapter.Fill(dt);

        //            ÖdemelerClass ÖC = new ÖdemelerClass();
        //            ÖC.Ödeme = float.Parse(dt.Rows[2][Musterino].ToString());

        //            return ÖC;


        //        }
        //        else
        //        {
        //            throw new Exception("Kuyruğa Erişilemiyor.");
        //        }
        //    }
        //    catch (Exception Ex)
        //    {

        //        throw new Exception("Giriş Hatası.");
        //    }
        //    finally
        //    {
        //        connection.Close(); // bağlantı kapatıldı.
        //    }
        //}


    }
}
