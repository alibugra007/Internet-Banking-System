﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Internet_Bankacılığı_Proje
{
    class HesaplarClass
    {
        private string TC;
        private string Ad;
        private string Soyad;
        private string Email;
        private string Sifre;
        private int MusteriNo;

        public string tC { get => TC; set => TC = value; }
        public string ad { get => Ad; set => Ad = value; }
        public string soyad { get => Soyad; set => Soyad = value; }
        public string email { get => Email; set => Email = value; }
        public string sifre { get => Sifre; set => Sifre = value; }
        public int musteriNo { get => MusteriNo; set => MusteriNo = value; }

        private static bool TCKontrolHesaplar(string tc)
        {

            try
            {
                string query = $"select * from Kayıt where [T.C. Kimlik Numarası] = '{tc}' ";
                return dbHelper.ExecuteQuery(query).Rows.Count >= 1;

            }
            catch (Exception Ex)
            {

                throw new Exception(Ex.Message);
            }

        }

        public int HesapEkle(HesaplarClass H)
        {
            try
            {
                if (TCKontrolHesaplar(H.tC))
                {
                    throw new Exception("Kullanıcı Zaten Mevcut.");
                }

                string query = $"INSERT INTO Kayıt([T.C. Kimlik Numarası],Ad,Soyad,Email,Sifre) Values('{H.TC}','{H.Ad}','{H.Soyad}','{H.Email}','{H.Sifre}')";
                return dbHelper.ExecuteNonQuery(query);

            }
            catch (Exception Ex)
            {

                throw new Exception(Ex.Message);
            }
        }

        public int HesabıSil(int hesapNum,string sifre)
        {
            SqlConnection connection = null;
            try
            {
                
                string query = $"DELETE KrediKart WHERE [Kredi Kartı Numarası]={hesapNum} AND [Kredi Kartı Şifre]='{sifre}'";
                return dbHelper.ExecuteNonQuery(query);

            }
            catch (Exception Ex)
            {

                throw new Exception(Ex.Message);
            }

        }

        public int HesapGüncelle(HesaplarClass HC)
        {
            SqlConnection connection = null;
            try
            {
                string query = $"UPDATE Kayıt  SET Ad = '{HC.ad}' ,Soyad={HC.soyad} WHERE [Müşteri Numarası]={HC.musteriNo}";
                return dbHelper.ExecuteNonQuery(query);

            }
            catch (Exception Ex)
            {

                throw new Exception(Ex.Message);
            }

        }

        public DataTable VadeliHesaplar(int musteriNo)
        {
            SqlConnection connection = null;
            try
            {

                //Kayıt tcalma = new Kayıt();
                //string tc = tcalma.tbTC.Text.Trim();

                string query = $"select [Kredi Kartı Numarası],[Kredi Kartı Limiti],[Kredi Kartı Borç],[Müşteri Numarası] from KrediKart where [Müşteri Numarası]={musteriNo}"; //where [T.C. Kimlik Numarası]={tc}

                return dbHelper.ExecuteQuery(query);

            }
            catch (Exception Ex)
            {

                throw new Exception(Ex.Message);
            }

        }

        public DataTable VadesizHesaplar(int musteriNo)
        {
            SqlConnection connection = null;
            try
            {

                //Kayıt tcalma = new Kayıt();
                //string tc = tcalma.tbTC.Text.Trim();

                string query = $"SELECT [Banka Kartı Numarası],[Banka Kartı Bakiyesi],[Müşteri Numarası] FROM BankaKart where [Müşteri Numarası]={musteriNo}"; //where [T.C. Kimlik Numarası]={tc}

                return dbHelper.ExecuteQuery(query);

            }
            catch (Exception Ex)
            {

                throw new Exception(Ex.Message);
            }

        }

    }
}
