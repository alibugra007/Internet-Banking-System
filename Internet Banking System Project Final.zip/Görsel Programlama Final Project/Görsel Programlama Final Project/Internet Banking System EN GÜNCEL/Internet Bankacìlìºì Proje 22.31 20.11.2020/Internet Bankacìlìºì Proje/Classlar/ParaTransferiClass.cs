﻿using Internet_Bankacılığı_Proje.Classlar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Internet_Bankacılığı_Proje
{
    class ParaTransferiClass
    {
        public void transferMoney(String sourceTckn, String targetTckn, double amount)
        {
            DbOperation.paraÇıkar(sourceTckn, amount);
            DbOperation.paraEkle(targetTckn, amount);
        }

    }
}
