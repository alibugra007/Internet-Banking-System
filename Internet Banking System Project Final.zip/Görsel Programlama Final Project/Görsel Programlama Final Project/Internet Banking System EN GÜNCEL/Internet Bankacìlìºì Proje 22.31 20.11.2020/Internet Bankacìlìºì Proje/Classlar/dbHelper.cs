﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Internet_Bankacılığı_Proje
{
    class dbHelper
    {

        public static DataTable ExecuteQuery(string query) // DataTable otomatik bir veri tipi veriler direkt tablo olarak gözüküyor useful.
        {
            SqlConnection connection = null;
            try
            {

                string conString = "Server=DESKTOP-FNI8T1F;Database=proje;Trusted_Connection=True;"; // bağlanma stringi connectionstring.com diye bir siteden alabiliriz.
                //Trusted_Connection=True demek windows authentication kullanıyoruz demek.

                connection = new SqlConnection(conString); // using System.Data.SqlClient; bunu en yukarıda import etmeliyiz yoksa çalışmaz.
                connection.Open(); // veri tabanıyla bağlantı yapıldı.

                if (connection.State == System.Data.ConnectionState.Open)
                {
                    // query = $"select * from Course "; yukarıda parametre olarak aldığı için gerek kalmadı buna

                    SqlCommand command = new SqlCommand(query, connection); // komutumuzu sql de yazmak için yaptık. 
                    SqlDataAdapter adapter = new SqlDataAdapter(command); // bilgiyi ordan okudu ve aldı.

                    DataTable dt = new DataTable(); // 2 boyutlu array gibi. Verileri kopyalamak için buraya.
                    adapter.Fill(dt); // veritabanına giricek, query yi yazıp çalıştıracak ve verileri getirecek.

                    return dt;

                }
                return null;
            }
            catch (Exception Ex)
            {

                throw new Exception(Ex.Message);
            }
            finally
            {
                connection.Close(); // bağlantı kapatıldı.
            }
        }


        public static int ExecuteNonQuery(string query)
        {
            SqlConnection connection = null;
            try
            {

                string conString = "Server=DESKTOP-FNI8T1F;Database=proje;Trusted_Connection=True;"; // bağlanma stringi connectionstring.com diye bir siteden alabiliriz.
                //Trusted_Connection=True demek windows authentication kullanıyoruz demek.

                connection = new SqlConnection(conString); // using System.Data.SqlClient; bunu en yukarıda import etmeliyiz yoksa çalışmaz.
                connection.Open(); // veri tabanıyla bağlantı yapıldı.

                if (connection.State == System.Data.ConnectionState.Open)
                {
                    // query = $"select * from Course "; yukarıda parametre olarak aldığı için gerek kalmadı buna

                    SqlCommand command = new SqlCommand(query, connection); // komutumuzu sql de yazmak için yaptık. 
                    return command.ExecuteNonQuery();

                }
                else
                {
                    throw new Exception("Kuyruğa Erişilemiyor.");
                }
            }
            catch (Exception Ex)
            {

                throw new Exception("Giriş Hatası.");
            }
            finally
            {
                connection.Close(); // bağlantı kapatıldı.
            }
        }

        
    }
}
