﻿using Internet_Bankacılığı_Proje.Classlar;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Internet_Bankacılığı_Proje
{
    class YatırımClass
    {   
        public void convertMoney(String kaynakParaBirimi, double kaynakTutar, String hedefParaBirimi)
        {
            String selectQuery = "select * from [Yatırım] where [TC kimlik no] = " + DbOperation.tcNo;
            DataTable selectDataTable = DbOperation.selectTransaction(selectQuery);

            double liraAmount = Double.Parse(selectDataTable.Rows[0]["lira"].ToString());
            double dolarAmount = Double.Parse(selectDataTable.Rows[0]["dolar"].ToString());
            double euroAmount = Double.Parse(selectDataTable.Rows[0]["euro"].ToString());

            if (kaynakParaBirimi == "lira" && hedefParaBirimi == "dolar") 
            {
                checkBalance(liraAmount, kaynakTutar);
                double hedefTutar = kaynakTutar / 7.66;
                liraAmount = liraAmount - kaynakTutar;
                dolarAmount = dolarAmount + hedefTutar;
            }

            else if (kaynakParaBirimi == "lira" && hedefParaBirimi == "euro")
            {
                checkBalance(liraAmount, kaynakTutar);
                double hedefTutar = kaynakTutar / 9.32;
                liraAmount = liraAmount - kaynakTutar;
                euroAmount = euroAmount + hedefTutar;
            }

            else if (kaynakParaBirimi == "dolar" && hedefParaBirimi == "lira")
            {
                checkBalance(dolarAmount, kaynakTutar);
                double hedefTutar = kaynakTutar / 9.32;
                dolarAmount = dolarAmount - kaynakTutar;
                liraAmount = liraAmount + hedefTutar;
            }

            else if (kaynakParaBirimi == "dolar" && hedefParaBirimi == "euro")
            {
                checkBalance(dolarAmount, kaynakTutar);
                double hedefTutar = kaynakTutar / 9.32;
                dolarAmount = dolarAmount - kaynakTutar;
                euroAmount = euroAmount + hedefTutar;
            }

            else if (kaynakParaBirimi == "euro" && hedefParaBirimi == "lira")
            {
                checkBalance(euroAmount, kaynakTutar);
                double hedefTutar = kaynakTutar / 9.32;
                euroAmount = euroAmount - kaynakTutar;
                liraAmount = liraAmount + hedefTutar;
            }

            else if (kaynakParaBirimi == "euro" && hedefParaBirimi == "dolar")
            {
                checkBalance(euroAmount, kaynakTutar);
                double hedefTutar = kaynakTutar / 9.32;
                euroAmount = euroAmount - kaynakTutar;
                dolarAmount = dolarAmount + hedefTutar;
            }
            DbOperation.updateYatırım(liraAmount, dolarAmount, euroAmount, DbOperation.tcNo);
        }

        public void checkBalance(double balance, double amount)
        {
            if(balance < amount)
            {
                throw new Exception("Bakiye yetersiz.");
            }
        }
    }
}
