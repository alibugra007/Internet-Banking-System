﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Internet_Bankacılığı_Proje
{
    class KayıtClass
    {
        private string TC;
        private string Ad;
        private string Soyad;
        private string Email;
        private string Sifre;

        public string tC { get => TC; set => TC = value; }
        public string ad { get => Ad; set => Ad = value; }
        public string soyad { get => Soyad; set => Soyad = value; }
        public string email { get => Email; set => Email = value; }
        public string sifre { get => Sifre; set => Sifre = value; }

        private static bool TCKontrol(string tc)
        {

            try
            {
                string query = $"select * from Kayıt where [T.C. Kimlik Numarası] = '{tc}' ";
                return dbHelper.ExecuteQuery(query).Rows.Count >= 1;

            }
            catch (Exception Ex)
            {

                throw new Exception(Ex.Message);
            }

        }

        public int KayıtEkle(KayıtClass k)
        {
            try
            {
                if (TCKontrol(k.tC))
                {
                    throw new Exception("Kullanıcı Zaten Mevcut.");
                }

                string query = $"INSERT INTO Kayıt([T.C. Kimlik Numarası],Ad,Soyad,Email,Sifre) Values('{k.TC}','{k.Ad}','{k.Soyad}','{k.Email}','{k.Sifre}')";
                return dbHelper.ExecuteNonQuery(query);

            }
            catch (Exception Ex)
            {

                throw new Exception(Ex.Message);
            }
        }


    }
}
