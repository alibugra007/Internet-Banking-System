﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Internet_Bankacılığı_Proje.Classlar
{
    public static class DbOperation
    {
        public static String tcNo = null;
        public static DataTable selectTransaction(String query)
        {
            SqlConnection connection = null;
            try
            {
                string conString = @"Data Source=DESKTOP-FNI8T1F;Initial Catalog=proje;Trusted_Connection=True";
                connection = new SqlConnection(conString);
                connection.Open();

                if (connection.State == System.Data.ConnectionState.Open)
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    return dt;
                }
            }
            catch (Exception ex)
            {
                Console.Out.Write("hata oluştu");
            }

            finally
            {
                connection.Close();
            }
            return null;
        }

        public static void updateYatırım(double lira, double dolar, double euro, String tcNo)
        {
            SqlConnection connection = null;
            try
            {
                string conString = @"Data Source=DESKTOP-FNI8T1F;Initial Catalog=proje;Trusted_Connection=True";
                connection = new SqlConnection(conString);
                connection.Open();

                if (connection.State == System.Data.ConnectionState.Open)
                {
                    SqlCommand SqlComm = new SqlCommand("UPDATE Yatırım set lira = @lira, dolar = @dolar, euro =@euro  WHERE [TC kimlik no] = @tcNo", connection);
                    SqlComm.Parameters.AddWithValue("@lira", lira);
                    SqlComm.Parameters.AddWithValue("@dolar", dolar);
                    SqlComm.Parameters.AddWithValue("@euro", euro);
                    SqlComm.Parameters.AddWithValue("@tcNo", tcNo);
                    SqlComm.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.Out.Write("hata oluştu");
            }

            finally
            {
                connection.Close();
            }
        }

        public static void paraÇıkar(String tckn, double amount)
        {
            SqlConnection connection = null;
            try
            {
                string conString = @"Data Source=DESKTOP-FNI8T1F;Initial Catalog=proje;Trusted_Connection=True";
                connection = new SqlConnection(conString);
                connection.Open();

                if (connection.State == System.Data.ConnectionState.Open)
                {
                    SqlCommand SqlComm = new SqlCommand("UPDATE Yatırım set lira = (lira - @lira), bankakartbakiye = (bankakartbakiye-@lira)   WHERE [TC kimlik no] = @tckn", connection);
                    SqlComm.Parameters.AddWithValue("@lira", amount);
                    SqlComm.Parameters.AddWithValue("@tckn", tckn);
                    SqlComm.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.Out.Write("hata oluştu");
            }

            finally
            {
                connection.Close();
            }
        }

        public static void paraEkle(String tckn, double amount)
        {
            SqlConnection connection = null;
            try
            {
                string conString = @"Data Source=DESKTOP-FNI8T1F;Initial Catalog=proje;Trusted_Connection=True";
                connection = new SqlConnection(conString);
                connection.Open();

                if (connection.State == System.Data.ConnectionState.Open)
                {
                    SqlCommand SqlComm = new SqlCommand("UPDATE Yatırım set lira = (lira + @lira), bankakartbakiye = (bankakartbakiye+@lira) WHERE [TC kimlik no] = @tckn", connection);
                    SqlComm.Parameters.AddWithValue("@lira", amount);
                    SqlComm.Parameters.AddWithValue("@tckn", tckn);
                    SqlComm.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.Out.Write("hata oluştu");
            }

            finally
            {
                connection.Close();
            }
        }
    }
}
