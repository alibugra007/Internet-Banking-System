﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Internet_Bankacılığı_Proje
{
    public partial class ŞansOyunları : Form
    {
        public ŞansOyunları()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SansOyunu1 sansOyunu1=new SansOyunu1();
            sansOyunu1.ShowDialog();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            SansOyunu2 sansOyunu2 = new SansOyunu2();
            sansOyunu2.ShowDialog();
        }
    }
}
