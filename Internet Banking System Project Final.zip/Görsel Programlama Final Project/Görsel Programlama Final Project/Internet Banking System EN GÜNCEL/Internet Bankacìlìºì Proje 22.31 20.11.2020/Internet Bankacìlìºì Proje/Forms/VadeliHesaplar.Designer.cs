﻿
namespace Internet_Bankacılığı_Proje
{
    partial class VadeliHesaplar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbMusteriNo = new System.Windows.Forms.TextBox();
            this.lblMusteriNo = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.dgvVadeliHesaplar = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVadeliHesaplar)).BeginInit();
            this.SuspendLayout();
            // 
            // tbMusteriNo
            // 
            this.tbMusteriNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbMusteriNo.Location = new System.Drawing.Point(257, 119);
            this.tbMusteriNo.Name = "tbMusteriNo";
            this.tbMusteriNo.Size = new System.Drawing.Size(243, 30);
            this.tbMusteriNo.TabIndex = 7;
            // 
            // lblMusteriNo
            // 
            this.lblMusteriNo.AutoSize = true;
            this.lblMusteriNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblMusteriNo.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lblMusteriNo.Location = new System.Drawing.Point(2, 119);
            this.lblMusteriNo.Name = "lblMusteriNo";
            this.lblMusteriNo.Size = new System.Drawing.Size(249, 25);
            this.lblMusteriNo.TabIndex = 6;
            this.lblMusteriNo.Text = "Müşteri Numaranızı Giriniz :";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.Location = new System.Drawing.Point(367, 172);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(133, 70);
            this.button1.TabIndex = 5;
            this.button1.Text = "Göster";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dgvVadeliHesaplar
            // 
            this.dgvVadeliHesaplar.AllowUserToAddRows = false;
            this.dgvVadeliHesaplar.AllowUserToDeleteRows = false;
            this.dgvVadeliHesaplar.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvVadeliHesaplar.BackgroundColor = System.Drawing.Color.Snow;
            this.dgvVadeliHesaplar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvVadeliHesaplar.Location = new System.Drawing.Point(538, -4);
            this.dgvVadeliHesaplar.Name = "dgvVadeliHesaplar";
            this.dgvVadeliHesaplar.ReadOnly = true;
            this.dgvVadeliHesaplar.RowHeadersWidth = 51;
            this.dgvVadeliHesaplar.RowTemplate.Height = 24;
            this.dgvVadeliHesaplar.Size = new System.Drawing.Size(529, 567);
            this.dgvVadeliHesaplar.TabIndex = 4;
            // 
            // VadeliHesaplar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumBlue;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.tbMusteriNo);
            this.Controls.Add(this.lblMusteriNo);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dgvVadeliHesaplar);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "VadeliHesaplar";
            this.Text = "VadeliHesaplar";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.dgvVadeliHesaplar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbMusteriNo;
        private System.Windows.Forms.Label lblMusteriNo;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dgvVadeliHesaplar;
    }
}