﻿
namespace Internet_Bankacılığı_Proje
{
    partial class BankaKartıGösterme
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbMusteriNo = new System.Windows.Forms.TextBox();
            this.lblMusteriNo = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.dgvBankaKartG = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBankaKartG)).BeginInit();
            this.SuspendLayout();
            // 
            // tbMusteriNo
            // 
            this.tbMusteriNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbMusteriNo.Location = new System.Drawing.Point(381, 76);
            this.tbMusteriNo.Name = "tbMusteriNo";
            this.tbMusteriNo.Size = new System.Drawing.Size(208, 38);
            this.tbMusteriNo.TabIndex = 11;
            // 
            // lblMusteriNo
            // 
            this.lblMusteriNo.AutoSize = true;
            this.lblMusteriNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblMusteriNo.ForeColor = System.Drawing.Color.Black;
            this.lblMusteriNo.Location = new System.Drawing.Point(12, 79);
            this.lblMusteriNo.Name = "lblMusteriNo";
            this.lblMusteriNo.Size = new System.Drawing.Size(363, 32);
            this.lblMusteriNo.TabIndex = 10;
            this.lblMusteriNo.Text = "Müşteri Numaranızı Giriniz :";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Black;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.Location = new System.Drawing.Point(433, 136);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(156, 81);
            this.button1.TabIndex = 9;
            this.button1.Text = "Göster";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dgvBankaKartG
            // 
            this.dgvBankaKartG.AllowUserToAddRows = false;
            this.dgvBankaKartG.AllowUserToDeleteRows = false;
            this.dgvBankaKartG.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvBankaKartG.BackgroundColor = System.Drawing.Color.PapayaWhip;
            this.dgvBankaKartG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBankaKartG.Location = new System.Drawing.Point(609, -1);
            this.dgvBankaKartG.Name = "dgvBankaKartG";
            this.dgvBankaKartG.ReadOnly = true;
            this.dgvBankaKartG.RowHeadersWidth = 51;
            this.dgvBankaKartG.RowTemplate.Height = 24;
            this.dgvBankaKartG.Size = new System.Drawing.Size(456, 560);
            this.dgvBankaKartG.TabIndex = 8;
            // 
            // BankaKartıGösterme
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.tbMusteriNo);
            this.Controls.Add(this.lblMusteriNo);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dgvBankaKartG);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "BankaKartıGösterme";
            this.Text = "BankaKartlarGösterme";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.BankaKartıGösterme_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBankaKartG)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbMusteriNo;
        private System.Windows.Forms.Label lblMusteriNo;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dgvBankaKartG;
    }
}