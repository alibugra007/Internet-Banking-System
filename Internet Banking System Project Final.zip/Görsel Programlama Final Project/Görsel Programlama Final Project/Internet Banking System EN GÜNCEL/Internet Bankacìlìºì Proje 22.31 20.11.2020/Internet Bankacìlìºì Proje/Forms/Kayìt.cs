﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Internet_Bankacılığı_Proje
{
    public partial class Kayıt : Form
    {
        public Kayıt()
        {
            InitializeComponent();
        }

        private void Kayıt_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                lblMessage.Text = "";
                lblMessage.ForeColor = Color.Black;

                string ad = tbAd.Text.Trim();
                string soyad = tbSoyad.Text.Trim();
                string tc = tbTC.Text.Trim();
                string email = tbEmail.Text.Trim();
                string sifre = tbSifre.Text.Trim();
       


                if (string.IsNullOrWhiteSpace(ad) || string.IsNullOrWhiteSpace(soyad) || string.IsNullOrWhiteSpace(tc)
                    || string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(sifre))
                {
                    MessageBox.Show("Boş Değer Olamaz.");
                }

                KayıtClass KC = new KayıtClass();
                KC.ad = ad;
                KC.soyad = soyad;
                KC.tC = tc;
                KC.email = email;
                KC.sifre = sifre;

                int result = KC.KayıtEkle(KC);

                if (result > 0) // eklemeyi yaptı mı diye kontrol.
                {
                    lblMessage.ForeColor = Color.Black;
                    lblMessage.Text = "Kayıt Başarıyla Eklendi.";
                }

            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message;
                lblMessage.ForeColor = Color.Red;
            }
        }

        public void tbTC_TextChanged(object sender, EventArgs e)
        {

        }
    }
  }

