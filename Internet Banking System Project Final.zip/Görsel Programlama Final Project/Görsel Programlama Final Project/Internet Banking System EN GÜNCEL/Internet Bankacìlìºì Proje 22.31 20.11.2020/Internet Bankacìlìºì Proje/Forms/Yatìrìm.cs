﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Internet_Bankacılığı_Proje
{
    public partial class Yatırım : Form
    {
        public Yatırım()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double birim = Convert.ToInt32(textBox1.Text);
            YatırımClass transferClass = new YatırımClass();

            try
            {
                if (comboBox1.SelectedItem.ToString() == "lira" && comboBox2.SelectedItem.ToString() == "dolar")
                {
                    transferClass.convertMoney("lira", birim, "dolar");
                    label1.Text = birim.ToString() + "TL";
                    label3.Text = (birim / 7.66).ToString() + "$";
                }

                else if (comboBox1.SelectedItem.ToString() == "lira" && comboBox2.SelectedItem.ToString() == "euro")
                {
                    transferClass.convertMoney("lira", birim, "euro");
                    label1.Text = birim.ToString() + "TL";
                    label3.Text = (birim / 9.32).ToString() + "€";
                }

                else if (comboBox1.SelectedItem.ToString() == "lira" && comboBox2.SelectedItem.ToString() == "lira")
                {
                    MessageBox.Show("Aynı cins para birimleriyle işlem yapamazsınız.");
                    return;
                }

                else if (comboBox1.SelectedItem.ToString() == "dolar" && comboBox2.SelectedItem.ToString() == "lira")
                {
                    transferClass.convertMoney("dolar", birim, "lira");
                    label1.Text = birim.ToString() + "$";
                    label3.Text = (birim * 7.66).ToString() + "TL";
                }

                else if (comboBox1.SelectedItem.ToString() == "dolar" && comboBox2.SelectedItem.ToString() == "euro")
                {
                    transferClass.convertMoney("dolar", birim, "euro");
                    label1.Text = birim.ToString() + "$";
                    label3.Text = (birim * 0.82).ToString() + "€";
                }

                else if (comboBox1.SelectedItem.ToString() == "dolar" && comboBox2.SelectedItem.ToString() == "dolar")
                {
                    MessageBox.Show("Aynı cins para birimleriyle işlem yapamazsınız.");
                    return;
                }

                else if (comboBox1.SelectedItem.ToString() == "euro" && comboBox2.SelectedItem.ToString() == "lira")
                {
                    transferClass.convertMoney("euro", birim, "lira");
                    label1.Text = birim.ToString() + "€";
                    label3.Text = (birim * 9.32).ToString() + "TL";
                }

                else if (comboBox1.SelectedItem.ToString() == "euro" && comboBox2.SelectedItem.ToString() == "dolar")
                {
                    transferClass.convertMoney("euro", birim, "dolar");
                    label1.Text = birim.ToString() + "€";
                    label3.Text = (birim * 0.82).ToString() + "$";
                }

                else if (comboBox1.SelectedItem.ToString() == "euro" && comboBox2.SelectedItem.ToString() == "euro")
                {
                    MessageBox.Show("Aynı cins para birimleriyle işlem yapamazsınız.");
                    return;
                }

                MessageBox.Show("İşleminiz başarıyla tamamlanmıştır.");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
