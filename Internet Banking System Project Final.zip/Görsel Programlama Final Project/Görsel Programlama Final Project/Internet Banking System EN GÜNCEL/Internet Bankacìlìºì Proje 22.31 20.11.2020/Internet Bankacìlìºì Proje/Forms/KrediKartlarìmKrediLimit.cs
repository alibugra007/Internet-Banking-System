﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Internet_Bankacılığı_Proje
{
    public partial class KrediKartlarımKrediLimit : Form
    {
        public KrediKartlarımKrediLimit()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dgvKrediKartLimit_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                //button1.Enabled = false;
                KartlarımClass KC = new KartlarımClass();

                int musteriNo = int.Parse(tbMusteriNo.Text.Trim());
                dgvKrediKartLimit.DataSource = KC.KrediKartLimit(musteriNo);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void KrediKartlarımKrediLimit_Load(object sender, EventArgs e)
        {

        }

        private void lblMusteriNo_Click(object sender, EventArgs e)
        {

        }

        private void tbMusteriNo_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
