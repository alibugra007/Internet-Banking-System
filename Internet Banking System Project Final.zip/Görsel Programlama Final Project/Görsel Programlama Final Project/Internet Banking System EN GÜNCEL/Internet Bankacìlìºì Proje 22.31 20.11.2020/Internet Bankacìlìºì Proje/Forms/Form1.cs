﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Internet_Bankacılığı_Proje.Classlar;

/*
 OnayEkran onayEkran = new OnayEkran();

            onayEkran.ShowDialog();
            this.Close();
 */


namespace Internet_Bankacılığı_Proje
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
          
        }

        
        

        private void button1_Click(object sender, EventArgs e)
        {
            string tcNo = textBox1.Text;
            string password = textBox2.Text;

            string query = $"select * from Musteri where [TC kimlik no] = " + tcNo + " and [kartsifre] = " + password;
            DataTable dt = DbOperation.selectTransaction(query);
            if (dt.Rows.Count > 0)
            {
                DbOperation.tcNo = dt.Rows[0]["TC kimlik no"].ToString();
                string email = dt.Rows[0]["email"].ToString();
                OnayEkran onayekran = new OnayEkran(email);
                onayekran.ShowDialog();
            }
            else
            {
                MessageBox.Show("Bilgilerinizi tekrar kontrol ediniz");
            }
        }

        private void Kayıt_Click(object sender, EventArgs e)
        {
            Kayıt kayıt = new Kayıt();
            kayıt.ShowDialog();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
