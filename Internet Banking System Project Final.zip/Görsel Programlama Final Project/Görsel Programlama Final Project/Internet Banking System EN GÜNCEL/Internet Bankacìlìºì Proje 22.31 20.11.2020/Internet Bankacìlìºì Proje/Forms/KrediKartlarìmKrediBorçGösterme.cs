﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Internet_Bankacılığı_Proje
{
    public partial class KrediKartlarımKrediBorçGösterme : Form
    {
        public KrediKartlarımKrediBorçGösterme()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void dgvKrediKartLimit_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tbMusteriNo_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblMusteriNo_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                ÖdemelerClass ÖC = new ÖdemelerClass();

                int musteriNo = int.Parse(tbMusteriNo.Text.Trim());
                dgvKrediKartBorçG.DataSource = ÖC.ÖdemelerKrediKartBorçG(musteriNo);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
    }
}
