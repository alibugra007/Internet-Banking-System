﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Internet_Bankacılığı_Proje
{
    public partial class YeniHesapAc : Form
    {
        public YeniHesapAc()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                lblMessage.Text = "";
                lblMessage.ForeColor = Color.Black;

                string ad = tbAd.Text.Trim();
                string soyad = tbSoyad.Text.Trim();
                string tc = tbTC.Text.Trim();
                string email = tbEmail.Text.Trim();
                string sifre = tbSifre.Text.Trim();



                if (string.IsNullOrWhiteSpace(ad) || string.IsNullOrWhiteSpace(soyad) || string.IsNullOrWhiteSpace(tc)
                    || string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(sifre))
                {
                    MessageBox.Show("Boş Değer Olamaz.");
                }

                HesaplarClass HC = new HesaplarClass();
                HC.ad = ad;
                HC.soyad = soyad;
                HC.tC = tc;
                HC.email = email;
                HC.sifre = sifre;

                int result = HC.HesapEkle(HC);

                if (result > 0) // eklemeyi yaptı mı diye kontrol.
                {
                    lblMessage.ForeColor = Color.Green;
                    lblMessage.Text = "Kayıt Başarıyla Eklendi.";
                }

            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message;
                lblMessage.ForeColor = Color.Red;
            }
        }
    }
}

