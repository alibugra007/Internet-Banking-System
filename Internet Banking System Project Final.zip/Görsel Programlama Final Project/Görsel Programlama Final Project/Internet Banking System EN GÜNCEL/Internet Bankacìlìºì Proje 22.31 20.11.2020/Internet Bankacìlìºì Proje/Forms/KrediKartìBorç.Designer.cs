﻿
namespace Internet_Bankacılığı_Proje
{
    partial class KrediKartıBorç
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbMusteriNo = new System.Windows.Forms.TextBox();
            this.lblMusteriNo = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.dgvÖdemelerKrediKB = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvÖdemelerKrediKB)).BeginInit();
            this.SuspendLayout();
            // 
            // tbMusteriNo
            // 
            this.tbMusteriNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbMusteriNo.Location = new System.Drawing.Point(321, 38);
            this.tbMusteriNo.Name = "tbMusteriNo";
            this.tbMusteriNo.Size = new System.Drawing.Size(243, 30);
            this.tbMusteriNo.TabIndex = 15;
            // 
            // lblMusteriNo
            // 
            this.lblMusteriNo.AutoSize = true;
            this.lblMusteriNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblMusteriNo.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lblMusteriNo.Location = new System.Drawing.Point(28, 41);
            this.lblMusteriNo.Name = "lblMusteriNo";
            this.lblMusteriNo.Size = new System.Drawing.Size(249, 25);
            this.lblMusteriNo.TabIndex = 14;
            this.lblMusteriNo.Text = "Müşteri Numaranızı Giriniz :";
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.Location = new System.Drawing.Point(876, 1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(179, 108);
            this.button1.TabIndex = 13;
            this.button1.Text = "Göster";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dgvÖdemelerKrediKB
            // 
            this.dgvÖdemelerKrediKB.AllowUserToAddRows = false;
            this.dgvÖdemelerKrediKB.AllowUserToDeleteRows = false;
            this.dgvÖdemelerKrediKB.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvÖdemelerKrediKB.BackgroundColor = System.Drawing.Color.Snow;
            this.dgvÖdemelerKrediKB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvÖdemelerKrediKB.Location = new System.Drawing.Point(0, 115);
            this.dgvÖdemelerKrediKB.Name = "dgvÖdemelerKrediKB";
            this.dgvÖdemelerKrediKB.ReadOnly = true;
            this.dgvÖdemelerKrediKB.RowHeadersWidth = 51;
            this.dgvÖdemelerKrediKB.RowTemplate.Height = 24;
            this.dgvÖdemelerKrediKB.Size = new System.Drawing.Size(1067, 438);
            this.dgvÖdemelerKrediKB.TabIndex = 12;
            // 
            // KrediKartıBorç
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aqua;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.tbMusteriNo);
            this.Controls.Add(this.lblMusteriNo);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dgvÖdemelerKrediKB);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "KrediKartıBorç";
            this.Text = "KrediKartıBorç";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.KrediKartıBorç_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvÖdemelerKrediKB)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbMusteriNo;
        private System.Windows.Forms.Label lblMusteriNo;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dgvÖdemelerKrediKB;
    }
}