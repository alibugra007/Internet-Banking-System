﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Internet_Bankacılığı_Proje
{
    public partial class HesabiSil : Form
    {
        public HesabiSil()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                
                string sifre = tbSifre.Text.Trim();
                int hesapNum = int.Parse(tbHesapNo.Text.Trim());

                var result = MessageBox.Show("Emin misiniz ?", "System Message", MessageBoxButtons.YesNo);

                if (result == DialogResult.Yes)
                {
                    HesaplarClass HC = new HesaplarClass();
                    var r = HC.HesabıSil(hesapNum,sifre);

                    if (r > 0)
                    {
                        MessageBox.Show("Hesap silindi.");
                    }
                    else
                    {
                        MessageBox.Show("Hesap silinemedi.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void HesabiSil_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
