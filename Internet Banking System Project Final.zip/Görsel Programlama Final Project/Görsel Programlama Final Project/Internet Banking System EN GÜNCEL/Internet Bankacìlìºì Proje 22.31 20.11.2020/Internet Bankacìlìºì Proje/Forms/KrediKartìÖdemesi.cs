﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Internet_Bankacılığı_Proje
{
    public partial class KrediKartıÖdemesi : Form
    {
        public KrediKartıÖdemesi()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int krediKartNum = int.Parse(tbKrediKartNo.Text.Trim());
            float odenecekDeger = float.Parse(tbKrediKartıBorç.Text.Trim());
            int musterinum = int.Parse(tbMüşteriNo.Text.Trim());

            ÖdemelerClass ÖC = new ÖdemelerClass();
          
            ÖC.ÖdemelerKrediKartıOdeme(odenecekDeger, krediKartNum, musterinum);
        }
    }
}
