﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Internet_Bankacılığı_Proje
{
    public partial class VadeliHesaplar : Form
    {
        public VadeliHesaplar()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                //button1.Enabled = false;
                HesaplarClass HC = new HesaplarClass();

                int musteriNo = int.Parse(tbMusteriNo.Text.Trim());
                dgvVadeliHesaplar.DataSource = HC.VadeliHesaplar(musteriNo);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
    }
}
