﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Mail;

namespace Internet_Bankacılığı_Proje
{
    public partial class OnayEkran : Form
    {
        String email = null;
        string onaykodu;

        public OnayEkran(String email)
        {
            this.email = email;
            InitializeComponent();
        }

        private void OnayEkran_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == onaykodu)
            {
                MessageBox.Show("Kaydınız başarılı oluşturuldu.");

            }
            else
            {
                MessageBox.Show("Kaydınız oluşturulamadı.", "hata");
            }

            

            AnaEkran anaEkran = new AnaEkran();

            anaEkran.ShowDialog();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();

            onaykodu = rnd.Next(100000, 999999).ToString();
            MailMessage mail = new MailMessage("gorselprogramlama123@gmail.com", this.email, "Güvenlik kod işlemi", "Güvenlik kodu : " + onaykodu);
            SmtpClient smtpClient = new SmtpClient("smtp.gmail.com", 587);
            smtpClient.EnableSsl = true;
            smtpClient.Credentials = new NetworkCredential("gorselprogramlama123@gmail.com", "gpp.1234");
            smtpClient.Send(mail);
            MessageBox.Show("Mail gönderildi..");


        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
