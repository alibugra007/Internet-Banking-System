﻿
namespace Internet_Bankacılığı_Proje
{
    partial class KrediKartlarımKrediLimit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(KrediKartlarımKrediLimit));
            this.dgvKrediKartLimit = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.lblMusteriNo = new System.Windows.Forms.Label();
            this.tbMusteriNo = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKrediKartLimit)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvKrediKartLimit
            // 
            this.dgvKrediKartLimit.AllowUserToAddRows = false;
            this.dgvKrediKartLimit.AllowUserToDeleteRows = false;
            this.dgvKrediKartLimit.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvKrediKartLimit.BackgroundColor = System.Drawing.Color.PapayaWhip;
            this.dgvKrediKartLimit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKrediKartLimit.Location = new System.Drawing.Point(0, 126);
            this.dgvKrediKartLimit.Name = "dgvKrediKartLimit";
            this.dgvKrediKartLimit.ReadOnly = true;
            this.dgvKrediKartLimit.RowHeadersWidth = 51;
            this.dgvKrediKartLimit.RowTemplate.Height = 24;
            this.dgvKrediKartLimit.Size = new System.Drawing.Size(1067, 428);
            this.dgvKrediKartLimit.TabIndex = 0;
            this.dgvKrediKartLimit.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvKrediKartLimit_CellContentClick);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.LightSalmon;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(816, 12);
            this.button1.Name = "button1";
            this.button1.Padding = new System.Windows.Forms.Padding(20, 0, 20, 0);
            this.button1.Size = new System.Drawing.Size(239, 108);
            this.button1.TabIndex = 1;
            this.button1.Text = "Göster";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblMusteriNo
            // 
            this.lblMusteriNo.AutoSize = true;
            this.lblMusteriNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblMusteriNo.ForeColor = System.Drawing.Color.White;
            this.lblMusteriNo.Location = new System.Drawing.Point(28, 52);
            this.lblMusteriNo.Name = "lblMusteriNo";
            this.lblMusteriNo.Size = new System.Drawing.Size(363, 32);
            this.lblMusteriNo.TabIndex = 2;
            this.lblMusteriNo.Text = "Müşteri Numaranızı Giriniz :";
            this.lblMusteriNo.Click += new System.EventHandler(this.lblMusteriNo_Click);
            // 
            // tbMusteriNo
            // 
            this.tbMusteriNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbMusteriNo.Location = new System.Drawing.Point(406, 49);
            this.tbMusteriNo.Name = "tbMusteriNo";
            this.tbMusteriNo.Size = new System.Drawing.Size(243, 38);
            this.tbMusteriNo.TabIndex = 3;
            this.tbMusteriNo.TextChanged += new System.EventHandler(this.tbMusteriNo_TextChanged);
            // 
            // KrediKartlarımKrediLimit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Navy;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.tbMusteriNo);
            this.Controls.Add(this.lblMusteriNo);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dgvKrediKartLimit);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "KrediKartlarımKrediLimit";
            this.Text = "KrediKartlarımKrediLimit";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.KrediKartlarımKrediLimit_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvKrediKartLimit)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvKrediKartLimit;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblMusteriNo;
        private System.Windows.Forms.TextBox tbMusteriNo;
    }
}