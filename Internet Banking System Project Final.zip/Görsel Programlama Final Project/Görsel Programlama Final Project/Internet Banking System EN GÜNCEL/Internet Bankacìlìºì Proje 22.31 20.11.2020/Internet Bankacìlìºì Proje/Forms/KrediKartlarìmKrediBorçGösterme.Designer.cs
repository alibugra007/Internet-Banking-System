﻿namespace Internet_Bankacılığı_Proje
{
    partial class KrediKartlarımKrediBorçGösterme
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(KrediKartlarımKrediBorçGösterme));
            this.tbMusteriNo = new System.Windows.Forms.TextBox();
            this.lblMusteriNo = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.dgvKrediKartBorçG = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKrediKartBorçG)).BeginInit();
            this.SuspendLayout();
            // 
            // tbMusteriNo
            // 
            this.tbMusteriNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbMusteriNo.Location = new System.Drawing.Point(410, 52);
            this.tbMusteriNo.Name = "tbMusteriNo";
            this.tbMusteriNo.Size = new System.Drawing.Size(243, 38);
            this.tbMusteriNo.TabIndex = 7;
            // 
            // lblMusteriNo
            // 
            this.lblMusteriNo.AutoSize = true;
            this.lblMusteriNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblMusteriNo.ForeColor = System.Drawing.Color.Black;
            this.lblMusteriNo.Location = new System.Drawing.Point(30, 55);
            this.lblMusteriNo.Name = "lblMusteriNo";
            this.lblMusteriNo.Size = new System.Drawing.Size(363, 32);
            this.lblMusteriNo.TabIndex = 6;
            this.lblMusteriNo.Text = "Müşteri Numaranızı Giriniz :";
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(806, 12);
            this.button1.Name = "button1";
            this.button1.Padding = new System.Windows.Forms.Padding(20, 0, 20, 0);
            this.button1.Size = new System.Drawing.Size(249, 111);
            this.button1.TabIndex = 5;
            this.button1.Text = "Göster";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dgvKrediKartBorçG
            // 
            this.dgvKrediKartBorçG.AllowUserToAddRows = false;
            this.dgvKrediKartBorçG.AllowUserToDeleteRows = false;
            this.dgvKrediKartBorçG.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvKrediKartBorçG.BackgroundColor = System.Drawing.Color.PapayaWhip;
            this.dgvKrediKartBorçG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKrediKartBorçG.Location = new System.Drawing.Point(0, 129);
            this.dgvKrediKartBorçG.Name = "dgvKrediKartBorçG";
            this.dgvKrediKartBorçG.ReadOnly = true;
            this.dgvKrediKartBorçG.RowHeadersWidth = 51;
            this.dgvKrediKartBorçG.RowTemplate.Height = 24;
            this.dgvKrediKartBorçG.Size = new System.Drawing.Size(1067, 428);
            this.dgvKrediKartBorçG.TabIndex = 4;
            // 
            // KrediKartlarımKrediBorçGösterme
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.tbMusteriNo);
            this.Controls.Add(this.lblMusteriNo);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dgvKrediKartBorçG);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "KrediKartlarımKrediBorçGösterme";
            this.Text = "KrediKartlarımKrediBorçGösterme";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.dgvKrediKartBorçG)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbMusteriNo;
        private System.Windows.Forms.Label lblMusteriNo;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dgvKrediKartBorçG;
    }
}