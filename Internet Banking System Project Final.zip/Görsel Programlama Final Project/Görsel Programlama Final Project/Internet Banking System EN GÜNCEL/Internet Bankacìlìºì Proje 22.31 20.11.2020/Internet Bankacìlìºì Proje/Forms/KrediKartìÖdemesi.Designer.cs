﻿
namespace Internet_Bankacılığı_Proje
{
    partial class KrediKartıÖdemesi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbKrediKartNo = new System.Windows.Forms.TextBox();
            this.lblKrediKartNum = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.dgvKrediKartıÖdeme = new System.Windows.Forms.DataGridView();
            this.lblKrediKartıBorç = new System.Windows.Forms.Label();
            this.tbKrediKartıBorç = new System.Windows.Forms.TextBox();
            this.lblMüşteriNo = new System.Windows.Forms.Label();
            this.tbMüşteriNo = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKrediKartıÖdeme)).BeginInit();
            this.SuspendLayout();
            // 
            // tbKrediKartNo
            // 
            this.tbKrediKartNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbKrediKartNo.Location = new System.Drawing.Point(315, 38);
            this.tbKrediKartNo.Name = "tbKrediKartNo";
            this.tbKrediKartNo.Size = new System.Drawing.Size(243, 30);
            this.tbKrediKartNo.TabIndex = 15;
            // 
            // lblKrediKartNum
            // 
            this.lblKrediKartNum.AutoSize = true;
            this.lblKrediKartNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKrediKartNum.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lblKrediKartNum.Location = new System.Drawing.Point(28, 41);
            this.lblKrediKartNum.Name = "lblKrediKartNum";
            this.lblKrediKartNum.Size = new System.Drawing.Size(281, 25);
            this.lblKrediKartNum.TabIndex = 14;
            this.lblKrediKartNum.Text = "Kredi Kartı Numaranızı Giriniz : ";
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.Location = new System.Drawing.Point(876, 11);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(179, 108);
            this.button1.TabIndex = 13;
            this.button1.Text = "ÖDE";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dgvKrediKartıÖdeme
            // 
            this.dgvKrediKartıÖdeme.AllowUserToAddRows = false;
            this.dgvKrediKartıÖdeme.AllowUserToDeleteRows = false;
            this.dgvKrediKartıÖdeme.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvKrediKartıÖdeme.BackgroundColor = System.Drawing.Color.Snow;
            this.dgvKrediKartıÖdeme.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKrediKartıÖdeme.Location = new System.Drawing.Point(0, 227);
            this.dgvKrediKartıÖdeme.Name = "dgvKrediKartıÖdeme";
            this.dgvKrediKartıÖdeme.ReadOnly = true;
            this.dgvKrediKartıÖdeme.RowHeadersWidth = 51;
            this.dgvKrediKartıÖdeme.RowTemplate.Height = 24;
            this.dgvKrediKartıÖdeme.Size = new System.Drawing.Size(1067, 326);
            this.dgvKrediKartıÖdeme.TabIndex = 12;
            // 
            // lblKrediKartıBorç
            // 
            this.lblKrediKartıBorç.AutoSize = true;
            this.lblKrediKartıBorç.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKrediKartıBorç.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lblKrediKartıBorç.Location = new System.Drawing.Point(40, 94);
            this.lblKrediKartıBorç.Name = "lblKrediKartıBorç";
            this.lblKrediKartıBorç.Size = new System.Drawing.Size(269, 25);
            this.lblKrediKartıBorç.TabIndex = 16;
            this.lblKrediKartıBorç.Text = "Ödeyeceğiniz Değeri Giriniz : ";
            // 
            // tbKrediKartıBorç
            // 
            this.tbKrediKartıBorç.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbKrediKartıBorç.Location = new System.Drawing.Point(315, 94);
            this.tbKrediKartıBorç.Name = "tbKrediKartıBorç";
            this.tbKrediKartıBorç.Size = new System.Drawing.Size(243, 30);
            this.tbKrediKartıBorç.TabIndex = 17;
            // 
            // lblMüşteriNo
            // 
            this.lblMüşteriNo.AutoSize = true;
            this.lblMüşteriNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblMüşteriNo.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lblMüşteriNo.Location = new System.Drawing.Point(187, 144);
            this.lblMüşteriNo.Name = "lblMüşteriNo";
            this.lblMüşteriNo.Size = new System.Drawing.Size(122, 25);
            this.lblMüşteriNo.TabIndex = 18;
            this.lblMüşteriNo.Text = "Müşteri No : ";
            // 
            // tbMüşteriNo
            // 
            this.tbMüşteriNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tbMüşteriNo.Location = new System.Drawing.Point(315, 144);
            this.tbMüşteriNo.Name = "tbMüşteriNo";
            this.tbMüşteriNo.Size = new System.Drawing.Size(243, 30);
            this.tbMüşteriNo.TabIndex = 19;
            // 
            // KrediKartıÖdemesi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleVioletRed;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.tbMüşteriNo);
            this.Controls.Add(this.lblMüşteriNo);
            this.Controls.Add(this.tbKrediKartıBorç);
            this.Controls.Add(this.lblKrediKartıBorç);
            this.Controls.Add(this.tbKrediKartNo);
            this.Controls.Add(this.lblKrediKartNum);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dgvKrediKartıÖdeme);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "KrediKartıÖdemesi";
            this.Text = "KrediKartıÖdemesi";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.dgvKrediKartıÖdeme)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbKrediKartNo;
        private System.Windows.Forms.Label lblKrediKartNum;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dgvKrediKartıÖdeme;
        private System.Windows.Forms.Label lblKrediKartıBorç;
        private System.Windows.Forms.TextBox tbKrediKartıBorç;
        private System.Windows.Forms.Label lblMüşteriNo;
        private System.Windows.Forms.TextBox tbMüşteriNo;
    }
}