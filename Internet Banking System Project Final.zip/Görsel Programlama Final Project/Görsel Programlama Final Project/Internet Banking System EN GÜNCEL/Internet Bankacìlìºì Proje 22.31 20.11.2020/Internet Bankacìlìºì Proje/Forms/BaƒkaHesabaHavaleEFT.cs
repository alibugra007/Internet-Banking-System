﻿using Internet_Bankacılığı_Proje.Classlar;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Internet_Bankacılığı_Proje
{
    public partial class BaşkaHesabaHavaleEFT : Form
    {
        public BaşkaHesabaHavaleEFT()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String targetTckn = tcknText.Text;
            double amount = Double.Parse(amountText.Text);
            ParaTransferiClass paraTransferi = new ParaTransferiClass();
            paraTransferi.transferMoney(DbOperation.tcNo, targetTckn, amount);
        }
    }
}
