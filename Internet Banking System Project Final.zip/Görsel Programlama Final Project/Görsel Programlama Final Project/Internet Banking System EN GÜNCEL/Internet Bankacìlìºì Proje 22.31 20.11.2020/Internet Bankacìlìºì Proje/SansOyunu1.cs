﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Internet_Bankacılığı_Proje
{
    public partial class SansOyunu1 : Form
    {
        public SansOyunu1()
        {
            InitializeComponent();
        }

        private void SansOyunu1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
          
        }


        int sayi=-1;
        private void button2_Click(object sender, EventArgs e)
        {
           Random r = new Random();
           sayi = r.Next(1,100);
           button2.Enabled = false;
        }

        int hak = 5;
        private void button1_Click_1(object sender, EventArgs e)
        {

            try
            {
                string NullorEmpty = SansOyunu1tb.Text.Trim();
                if (String.IsNullOrEmpty(NullorEmpty))
                {
                    MessageBox.Show("Tahmin Etmek İçin Sayı Girmelisiniz.");
                    SansOyunu1tb.Focus();
                    return;
                }

                int tahminEdilenSayi = int.Parse(SansOyunu1tb.Text.Trim());
                
                if (sayi == -1)
                {
                    MessageBox.Show("İlk Önce Rastgele Sayı Oluşturmalısınız.");
                }
                if (sayi != -1)
                {
                    if (hak != 0)
                    {

                        if (tahminEdilenSayi > sayi)
                        {
                            hak--;
                            haklbl.Text = $"Kalan Hakkınız: {hak}";
                            Durumlbl.ForeColor = Color.Black;
                            Durumlbl.Text = "Sayınız Büyük !!";
                        }
                        else if (tahminEdilenSayi < sayi)
                        {
                            hak--;
                            haklbl.Text = $"Kalan Hakkınız: {hak}";
                            Durumlbl.ForeColor = Color.Black;
                            Durumlbl.Text = "Sayınız Küçük !!";
                        }
                        else if (tahminEdilenSayi == sayi)
                        {
                            Durumlbl.ForeColor = Color.Green;
                            Durumlbl.Text = "Tebrikler, bildiniz.";
                        }
                    }
                    if (hak == 0)
                    {
                        button1.Enabled = false;

                        haklbl.Text = $"Hakkınız bitti. Sayı: {sayi}";
                        
                        Durumlbl.Text = "Çıkış Yapabilirsiniz.";                     
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }
        
    }

}
