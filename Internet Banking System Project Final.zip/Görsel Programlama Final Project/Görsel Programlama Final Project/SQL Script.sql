USE [proje]
GO
/****** Object:  Table [dbo].[BankaKart]    Script Date: 10.01.2021 19:17:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BankaKart](
	[Banka Kartı Numarası] [int] IDENTITY(3000,1) NOT NULL,
	[Banka Kartı Bakiyesi] [float] NOT NULL,
	[Banka Kartı Şifre] [nvarchar](20) NOT NULL,
	[Müşteri Numarası] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Kayıt]    Script Date: 10.01.2021 19:17:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Kayıt](
	[T.C. Kimlik Numarası] [nvarchar](11) NOT NULL,
	[Ad] [nvarchar](50) NOT NULL,
	[Soyad] [nvarchar](50) NOT NULL,
	[Email] [nvarchar](50) NOT NULL,
	[Sifre] [nvarchar](50) NOT NULL,
	[Müşteri Numarası] [int] IDENTITY(10000,1) NOT NULL,
 CONSTRAINT [PK_Kayıt] PRIMARY KEY CLUSTERED 
(
	[Müşteri Numarası] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[KrediKart]    Script Date: 10.01.2021 19:17:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[KrediKart](
	[Kredi Kartı Numarası] [int] IDENTITY(1000,1) NOT NULL,
	[Kredi Kartı Limiti] [float] NOT NULL,
	[Kredi Kartı Borç] [float] NOT NULL,
	[Kredi Kartı Şifre] [nvarchar](20) NOT NULL,
	[Müşteri Numarası] [int] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Musteri]    Script Date: 10.01.2021 19:17:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Musteri](
	[TC kimlik no] [nvarchar](11) NOT NULL,
	[musterino] [varchar](50) NULL,
	[bankakartno] [varchar](50) NULL,
	[kredikartno] [varchar](50) NULL,
	[kartsifre] [varchar](50) NULL,
	[ad] [varchar](50) NULL,
	[soyad] [varchar](50) NULL,
	[email] [varchar](50) NULL,
 CONSTRAINT [PK_Person] PRIMARY KEY CLUSTERED 
(
	[TC kimlik no] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Yatırım]    Script Date: 10.01.2021 19:17:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Yatırım](
	[yatırımId] [int] IDENTITY(1,1) NOT NULL,
	[bankakartbakiye] [decimal](18, 0) NULL,
	[dolar] [decimal](18, 0) NULL,
	[euro] [decimal](18, 0) NULL,
	[lira] [decimal](18, 0) NULL,
	[TC kimlik no] [nvarchar](11) NULL,
PRIMARY KEY CLUSTERED 
(
	[yatırımId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[BankaKart] ON 
GO
INSERT [dbo].[BankaKart] ([Banka Kartı Numarası], [Banka Kartı Bakiyesi], [Banka Kartı Şifre], [Müşteri Numarası]) VALUES (3002, 3200, N'bank1', 10000)
GO
SET IDENTITY_INSERT [dbo].[BankaKart] OFF
GO
SET IDENTITY_INSERT [dbo].[Kayıt] ON 
GO
INSERT [dbo].[Kayıt] ([T.C. Kimlik Numarası], [Ad], [Soyad], [Email], [Sifre], [Müşteri Numarası]) VALUES (N'12345678911', N'Ali Buğra', N'Oktay', N'alibugra@alibugra.com', N'sifre', 10000)
GO
INSERT [dbo].[Kayıt] ([T.C. Kimlik Numarası], [Ad], [Soyad], [Email], [Sifre], [Müşteri Numarası]) VALUES (N'32145653241', N'Emin
Emin', N'Tümer', N'emin@emin.com', N'emin', 10001)
GO
INSERT [dbo].[Kayıt] ([T.C. Kimlik Numarası], [Ad], [Soyad], [Email], [Sifre], [Müşteri Numarası]) VALUES (N'12364512321', N'ad', N'soyad', N'email', N'sifre', 10002)
GO
INSERT [dbo].[Kayıt] ([T.C. Kimlik Numarası], [Ad], [Soyad], [Email], [Sifre], [Müşteri Numarası]) VALUES (N'01928374857', N'Ali Buğra', N'Oktay', N'bugra@gmail.com', N'bugra', 10004)
GO
INSERT [dbo].[Kayıt] ([T.C. Kimlik Numarası], [Ad], [Soyad], [Email], [Sifre], [Müşteri Numarası]) VALUES (N'15975385245', N'Ali Buğra', N'Oktay', N'alibugraoktay@gmail.com', N'147852369', 10005)
GO
INSERT [dbo].[Kayıt] ([T.C. Kimlik Numarası], [Ad], [Soyad], [Email], [Sifre], [Müşteri Numarası]) VALUES (N'14236457689', N'Ali Buğra', N'Oktay', N'alibugrawork@gmail.com', N'123456756', 10006)
GO
SET IDENTITY_INSERT [dbo].[Kayıt] OFF
GO
SET IDENTITY_INSERT [dbo].[KrediKart] ON 
GO
INSERT [dbo].[KrediKart] ([Kredi Kartı Numarası], [Kredi Kartı Limiti], [Kredi Kartı Borç], [Kredi Kartı Şifre], [Müşteri Numarası]) VALUES (1002, 15682, 9760, N'ghi2', 10000)
GO
INSERT [dbo].[KrediKart] ([Kredi Kartı Numarası], [Kredi Kartı Limiti], [Kredi Kartı Borç], [Kredi Kartı Şifre], [Müşteri Numarası]) VALUES (1003, 5322, 2400, N'abc4', 10001)
GO
INSERT [dbo].[KrediKart] ([Kredi Kartı Numarası], [Kredi Kartı Limiti], [Kredi Kartı Borç], [Kredi Kartı Şifre], [Müşteri Numarası]) VALUES (1004, 6400, 3200, N'ggh2', 10002)
GO
INSERT [dbo].[KrediKart] ([Kredi Kartı Numarası], [Kredi Kartı Limiti], [Kredi Kartı Borç], [Kredi Kartı Şifre], [Müşteri Numarası]) VALUES (1005, 9700, 6900, N'oo2', 10000)
GO
SET IDENTITY_INSERT [dbo].[KrediKart] OFF
GO
INSERT [dbo].[Musteri] ([TC kimlik no], [musterino], [bankakartno], [kredikartno], [kartsifre], [ad], [soyad], [email]) VALUES (N'01234567897', N'446754', N'3333222211117777', N'2222333377771111', N'132465', N'ali', N'oktay', N'alibugrawork@gmail.com')
GO
INSERT [dbo].[Musteri] ([TC kimlik no], [musterino], [bankakartno], [kredikartno], [kartsifre], [ad], [soyad], [email]) VALUES (N'01234567898', N'458745', N'1111222233334444', N'1111222233334444', N'123456', N'busra', N'pece', N'busrapece@gmail.com')
GO
INSERT [dbo].[Musteri] ([TC kimlik no], [musterino], [bankakartno], [kredikartno], [kartsifre], [ad], [soyad], [email]) VALUES (N'01234567899', N'971553', N'1111222233334444', N'1111222233334444', N'123456', N'oguz', N'pece', N'oguzpece07@gmail.com')
GO
SET IDENTITY_INSERT [dbo].[Yatırım] ON 
GO
INSERT [dbo].[Yatırım] ([yatırımId], [bankakartbakiye], [dolar], [euro], [lira], [TC kimlik no]) VALUES (2, CAST(9434 AS Decimal(18, 0)), CAST(134 AS Decimal(18, 0)), CAST(3 AS Decimal(18, 0)), CAST(8533 AS Decimal(18, 0)), N'01234567899')
GO
INSERT [dbo].[Yatırım] ([yatırımId], [bankakartbakiye], [dolar], [euro], [lira], [TC kimlik no]) VALUES (3, CAST(1000566 AS Decimal(18, 0)), CAST(0 AS Decimal(18, 0)), CAST(0 AS Decimal(18, 0)), CAST(1000566 AS Decimal(18, 0)), N'01234567898')
GO
SET IDENTITY_INSERT [dbo].[Yatırım] OFF
GO
ALTER TABLE [dbo].[Yatırım] ADD  DEFAULT ((0)) FOR [bankakartbakiye]
GO
ALTER TABLE [dbo].[Yatırım] ADD  DEFAULT ((0)) FOR [dolar]
GO
ALTER TABLE [dbo].[Yatırım] ADD  DEFAULT ((0)) FOR [euro]
GO
ALTER TABLE [dbo].[Yatırım] ADD  DEFAULT ((0)) FOR [lira]
GO
ALTER TABLE [dbo].[BankaKart]  WITH CHECK ADD  CONSTRAINT [FK_BankaKart_Kayıt] FOREIGN KEY([Müşteri Numarası])
REFERENCES [dbo].[Kayıt] ([Müşteri Numarası])
GO
ALTER TABLE [dbo].[BankaKart] CHECK CONSTRAINT [FK_BankaKart_Kayıt]
GO
ALTER TABLE [dbo].[KrediKart]  WITH CHECK ADD  CONSTRAINT [FK_KrediKart_Kayıt] FOREIGN KEY([Müşteri Numarası])
REFERENCES [dbo].[Kayıt] ([Müşteri Numarası])
GO
ALTER TABLE [dbo].[KrediKart] CHECK CONSTRAINT [FK_KrediKart_Kayıt]
GO
ALTER TABLE [dbo].[Yatırım]  WITH CHECK ADD FOREIGN KEY([TC kimlik no])
REFERENCES [dbo].[Musteri] ([TC kimlik no])
GO
